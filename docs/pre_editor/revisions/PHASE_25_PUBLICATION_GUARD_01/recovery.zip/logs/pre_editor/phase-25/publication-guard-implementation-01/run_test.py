"""Bounded offline-test accounting. Never invokes a real checkpoint command."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('attempt')
    parser.add_argument('script')
    parser.add_argument('arguments', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    assert args.attempt.replace('-', '').replace('_', '').isalnum()
    script = (ROOT / args.script).resolve()
    assert script.is_relative_to(BASE / 'tests') and script.is_file()
    ledger_path = BASE / 'test-ledger.json'
    ledger = json.loads(ledger_path.read_text(encoding='utf-8'))
    assert ledger['limits'] == {'per_invocation_seconds': 120, 'cumulative_seconds': 600}
    assert 600 - ledger['used_seconds'] >= 120, 'Insufficient full invocation reservation'
    destination = BASE / 'test-runs' / args.attempt
    destination.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, '-B', str(script), *args.arguments]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = encode(ledger)
    (destination / 'ledger-before.json').write_bytes(before)
    (destination / 'invocation.json').write_bytes(encode({
        'command': command, 'cwd': str(ROOT), 'started_utc': started,
        'timeout_seconds': 120, 'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
        'helper_sha256': hashlib.sha256((ROOT / '.codex/tools/rendering_checkpoint.py').read_bytes()).hexdigest(),
        'offline_only': True,
    }))
    tick = time.perf_counter()
    try:
        result = subprocess.run(command, cwd=ROOT, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'),
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
        outcome = 'PASS' if code == 0 else 'FAIL'
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b'', error.stderr or b'', None
        outcome = 'TIMEOUT'
    elapsed = time.perf_counter() - tick
    (destination / 'stdout.txt').write_bytes(stdout)
    (destination / 'stderr.txt').write_bytes(stderr)
    record = {'attempt': args.attempt, 'outcome': outcome, 'exit_code': code,
              'seconds': elapsed, 'command': command, 'started_utc': started,
              'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'ledger_before_sha256': hashlib.sha256(before).hexdigest()}
    ledger['used_seconds'] += elapsed
    ledger['attempts'].append(record)
    (destination / 'result.json').write_bytes(encode(record))
    after = encode(ledger)
    (destination / 'ledger-after.json').write_bytes(after)
    ledger_path.write_bytes(after)
    print(json.dumps({'attempt': args.attempt, 'outcome': outcome, 'seconds': elapsed,
                      'used_seconds': ledger['used_seconds'], 'remaining_seconds': 600-ledger['used_seconds']}), flush=True)
    print(stdout.decode('utf-8', 'replace')[-7000:], flush=True)
    print(stderr.decode('utf-8', 'replace')[-7000:], flush=True)
    return 0 if outcome == 'PASS' and elapsed <= 120 and ledger['used_seconds'] <= 600 else 1


if __name__ == '__main__':
    raise SystemExit(main())
