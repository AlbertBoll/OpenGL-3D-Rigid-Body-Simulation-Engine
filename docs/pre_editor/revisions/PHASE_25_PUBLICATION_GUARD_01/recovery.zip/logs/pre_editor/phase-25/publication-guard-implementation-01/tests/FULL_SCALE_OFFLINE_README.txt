Full-scale Phase25 preservation verification

Prepared only; this file does not assert execution or PASS.

The parent controller runs full_scale_offline.py in three separate invocations:

  python -B <script> capture --session <new-tests-subdirectory> --helper-sha256 <pinned-authorized-helper-sha256> --report <new-tests-result-path>
  python -B <script> check --session <same-tests-subdirectory> --helper-sha256 <same-sha256> --report <different-new-tests-result-path>
  python -B <script> recovery --session <same-tests-subdirectory> --helper-sha256 <same-sha256> --report <different-new-tests-result-path>

Every output path must resolve below:
logs/pre_editor/phase-25/publication-guard-implementation-01/tests/

Use the existing parent-controlled 120-second invocation and 600-second
cumulative test budget. The script has a 115-second internal deadline. It
performs no automatic retry; preserve every failure and choose a new report
path for a correction attempt. Capture requires a new session directory.

Scope:
* The accepted 8,028 bin paths total 28,151,404,975 logical bytes. Each mode
  reads them, the seven historical paths and six guard files using the actual
  helper's sequential Repo.path and Repo.fingerprint implementations.
* Five unchanged guard identities are pinned to the original candidate; the
  authorized helper identity is supplied by the parent and recorded. Catalog
  content/membership remains pinned to its accepted SHA-256.
* Capture compares real bytes with the accepted catalog and serializes the
  entire fixture closure. It reloads that closure and verifies a canonical
  JSON round-trip. Check calls actual verify_mutable and check_hashes on the
  reloaded full map. No protected fingerprints are substituted.
* Recovery calls the actual check(..., pending=True), verify_mutable and the
  Phase25 predecessor gate. It rereads all protected files and uses the
  original journal state alongside a simulated advanced workflow state.
* Receipt/journal/state are clearly marked synthetic and live only below the
  test directory. Fixture Phase25 retention references are read-only aliases
  to actual Phase24 retained references and actual raw/filtered Git objects.
  No Phase25 retention ref, real receipt, real journal or transaction is made.
  The synthetic canonical snapshot retains the historical Phase24 fingerprint;
  actual current canonical bytes are recorded and preserved separately. Actual
  predecessor refs and raw/filtered blobs are checked before each full scan.
* The actual current main.cpp bytes are pinned and preserved. Listing current
  nonprotected changed paths in fixture membership grants no production scope,
  source acceptance, engine PASS, human PASS, or publication eligibility.

Every result records actual file/read counts, logical bytes, maximum absolute
and relative Windows path lengths, largest file, stable per-read metadata,
Windows GetProcessMemoryInfo peak working-set/commit counters, Python pointer
width, GlobalMemoryStatusEx system resource context, process I/O counters,
elapsed/CPU time, the existing junction's containment and exact
target, full snapshot identity, and before/after real HEAD/index/ref/state
identities. The Git adapter allows local read operations only, supplies
-c safe.directory for this exact root, and forbids object/index/ref/publication
writes. The helper library is loaded from pinned bytes without modification.

Limits:
* This verifies the actual inventory and the pending validation stage, not
  actual interrupted staging, commit, tag, push or publication. Those require
  separate bounded offline control-flow fixtures; no real transaction runs.
* The existing live junction is inspected but never created, altered or
  removed. No claim of a live negative retargeting experiment is made.
* Metadata before/after each read plus hashes detects observed drift. The test
  does not freeze the filesystem against adversarial concurrent changes.
* Memory/path results cover this exact inventory. No bound for arbitrary
  future build outputs or paths is asserted. The helper still uses read_bytes.
* OS I/O counters and counted logical reads are not a cold-disk benchmark.

The script never invokes seal, finish, pin_mutable, helper atomic writes,
network access, engine builds, applications, performance qualification or
cleanup. It creates no junction and deletes no file.
