#!/usr/bin/env python3
"""Three bounded, read-only real-inventory checks; never seal or finish.

Run capture, check, and recovery in separate invocations under the parent's
120-second invocation / 600-second cumulative budget. All writes are confined
to this script's test directory. The existing helper's path, fingerprint,
check_hashes, verify_mutable, and pending check implementations are executed.
No protected-file hash is mocked, cached, substituted, or read in parallel.

Recovery uses synthetic receipt/journal/state files and aliases the fixture's
Phase25 retention-ref lookups to the real Phase24 retained refs and Git blobs.
This does not create a Phase25 seal, transaction, approval, or eligibility.
"""
import argparse
import base64
import copy
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import traceback
import types

sys.dont_write_bytecode = True

ROOT = Path('C:/dev/GEngine-pre-editor').resolve()
TEST_ROOT = ROOT / 'logs/pre_editor/phase-25/publication-guard-implementation-01/tests'
HELPER = '.codex/tools/rendering_checkpoint.py'
SPEC = 'logs/pre_editor/phase-25/game-acceptance-01/checkpoint-spec.json'
CATALOG = 'docs/pre_editor/proposals/PHASE_25_FINAL_PUBLICATION_GUARD_RESOLUTION_01/path-classification.json'
CATALOG_SHA = '023ffd91e9d5215094651a19a706c2c7fe437ed7b6e0779665b4eb99b6ca7ca5'
CANONICAL = 'RigidBodySimulation/src/RigidBodySimulation.cpp'
MAIN = 'RigidBodySimulation/src/main.cpp'
PENDING_MAIN_SHA = 'a90238e28a551c263211179354de19f09394c19b292cc0a96c1ca060a2204f4b'
BASELINE = '871e065c53cb7364d2e8091dfff7e0080db14869'
GUARDS = {
    '.agents/skills/pre-editor-phase-execution/SKILL.md': '96eacfc7a63a8d0ee3a38845458a406cde423bc34684d57a8fe9bd8b1042b512',
    '.agents/skills/pre-editor-phase-approval/SKILL.md': '804ac8fac49f3833f92070b45095f344f4172fa81aedc85916981e61326d546f',
    '.agents/skills/pre-editor-phase-rejection/SKILL.md': '341f1fe029214fc9fd983e370461e2c2ebcbb7332669b9aed8ca1f97f0143385',
    'docs/pre_editor/active/PUBLICATION_POLICY.json': 'b563638703dc657ecc06a321e435bb15da2eba5f04537d903b28fb40ea31a1cd',
    'docs/pre_editor/active/PUBLICATION_GRANT.json': '0e30b43e67b450a07d77893f4784e32dae38135219610151ef3fd48e4beebe60',
}
LIMITS = [
    'Only fixture receipt/journal/state and report files are written; the real Phase25 receipt and journal must remain absent.',
    'All 8041 protected fingerprints use actual helper Repo.path and Repo.fingerprint over real files; no protected hash substitutions.',
    'Pending recovery uses synthetic control metadata and Phase25 retention-ref aliases to existing real Phase24 refs/blobs; no actual Phase25 retention refs exist or are created.',
    'Recovery exercises the real pending check with original journal state and simulated advanced state; it does not execute interrupted staging, commit, tag, push, or finish.',
    'Existing actual junction containment/target and per-read file metadata are checked; no live junction is created, retargeted, or removed.',
    'Measured memory and path/file maxima cover this actual inventory, not arbitrary future outputs; the helper retains its existing whole-file read behavior.',
    'Hashes and before/after file metadata detect observed drift; this is not an atomic filesystem freeze against adversarial concurrent edits.',
    'Synthetic receipt eligible=true is solely required by the check schema; actual main.cpp disposition, engine validation, human acceptance and phase approval remain unresolved and are not asserted.',
]


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')


def output_path(value):
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = ROOT / candidate
    candidate = candidate.resolve()
    need(candidate.is_relative_to(TEST_ROOT.resolve()), 'Output leaves the authorized tests directory')
    return candidate


def write_new(path, data):
    path = output_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(data)
        out.flush()
        os.fsync(out.fileno())


def rel(path):
    return Path(path).relative_to(ROOT).as_posix()


class MemoryCounters(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in (
            'PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
            'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
            'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage', 'PrivateUsage')]


class IoCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in (
        'ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
        'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]


def windows_resources():
    need(os.name == 'nt', 'This verification requires the actual Windows worktree')
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    handle = kernel.GetCurrentProcess()
    memory = MemoryCounters()
    memory.cb = ctypes.sizeof(memory)
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    need(psapi.GetProcessMemoryInfo(handle, ctypes.byref(memory), memory.cb), 'GetProcessMemoryInfo failed')
    io = IoCounters()
    kernel.GetProcessIoCounters.argtypes = [wintypes.HANDLE, ctypes.POINTER(IoCounters)]
    kernel.GetProcessIoCounters.restype = wintypes.BOOL
    need(kernel.GetProcessIoCounters(handle, ctypes.byref(io)), 'GetProcessIoCounters failed')
    return {
        'memory_bytes': {name: getattr(memory, name) for name, _ in memory._fields_ if name not in ('cb', 'PageFaultCount')},
        'page_fault_count': memory.PageFaultCount,
        'process_io_counters': {name: getattr(io, name) for name, _ in io._fields_},
        'io_note': 'OS process I/O counters are not claimed as uncached physical-disk traffic.',
    }


def stat_identity(path):
    s = path.stat()
    return [s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_dev, s.st_ino, s.st_mode]


def parse_state(raw, helper):
    text = raw.decode('utf-8')
    state = {}
    for key in ('Refactor branch', 'Configured remote', *helper.FIELDS):
        values = re.findall(r'^- ' + re.escape(key) + r': `([^`]+)`\s*$', text, re.M)
        need(len(values) == 1, 'Ambiguous fixture state: ' + key)
        state[key] = values[0]
    return raw, state


def make_repo(helper, catalog_rows, protected, deadline):
    class ReadOnlyRepo(helper.Repo):
        def __init__(self):
            self.metrics = {'path_calls': 0, 'fingerprint_calls': 0, 'successful_fingerprint_bytes': 0,
                            'protected_fingerprint_calls': 0, 'protected_fingerprint_bytes': 0,
                            'bin_fingerprint_calls': 0, 'bin_fingerprint_bytes': 0,
                            'max_absolute_path_characters': 0, 'max_relative_path_characters': 0,
                            'largest_file_bytes': 0, 'stable_fingerprint_reads': 0}
            self.read_counts = {}
            self.git_calls = []
            self.active_read = None
            self.active_identity = None
            self.active_path = None
            self.fixture_state = None
            self.fixture_journal = None
            self.aliases = {}
            super().__init__(ROOT)

        def git(self, *args, input=None, allow_failure=False):
            need(time.monotonic() < deadline, 'Invocation deadline reached before Git read')
            need(args, 'Empty Git command')
            command = args[0]
            allowed = {'rev-parse', 'ls-files', 'diff', 'cat-file', 'show-ref', 'show',
                       'hash-object', 'check-ignore', 'check-ref-format', 'branch', 'remote', 'config'}
            need(command in allowed, 'Non-read-only Git command forbidden: ' + command)
            need(command != 'hash-object' or '-w' not in args, 'Git object writes forbidden')
            need(command != 'branch' or args == ('branch', '--show-current'), 'Only branch discovery allowed')
            need(command != 'remote' or len(args) == 1 or args[1] == 'get-url', 'Only remote discovery allowed')
            need(command != 'config' or args[1:] == ('--bool', '--get', 'core.filemode'), 'Only filemode configuration read allowed')
            need(command != 'diff' or not any(a == '--output' or a.startswith('--output=') for a in args), 'Git diff file output forbidden')
            actual = args
            if command == 'show-ref' and args[-1] in self.aliases:
                need(args[1:-1] == ('--verify', '--hash'), 'Unexpected virtual-ref operation')
                actual = (*args[:-1], self.aliases[args[-1]]['real_ref'])
            self.git_calls.append({'requested': list(args), 'actual_read': list(actual)})
            remaining = max(0.1, deadline - time.monotonic())
            environment = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
            process = subprocess.run(
                ['git', '--no-optional-locks', '-c', 'safe.directory=' + ROOT.as_posix(), '-C', str(ROOT), *actual],
                input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=environment, timeout=remaining)
            if command == 'show-ref' and args[-1] in self.aliases:
                need(process.returncode == 0 and process.stdout.decode().strip() == self.aliases[args[-1]]['oid'],
                     'Real predecessor retention reference does not match fixture alias')
            if process.returncode and not allow_failure:
                raise helper.Blocked('Read-only git ' + command + ' failed: ' + process.stderr.decode('utf-8', 'replace')[-2400:])
            return process if allow_failure else process.stdout

        def path(self, name):
            path = super().path(name)
            self.metrics['path_calls'] += 1
            row = catalog_rows.get(name)
            if row and row.get('resolved', name) != name:
                need(path.resolve() == (self.root / row['resolved']).resolve(), 'Catalog resolved path changed: ' + name)
            if self.active_read == name:
                self.active_path = path
                self.active_identity = stat_identity(path)
            length = len(str(path))
            if length > self.metrics['max_absolute_path_characters']:
                self.metrics['max_absolute_path_characters'] = length
                self.metrics['longest_absolute_path'] = str(path)
            self.metrics['max_relative_path_characters'] = max(self.metrics['max_relative_path_characters'], len(name))
            return path

        def fingerprint(self, name):
            need(time.monotonic() < deadline, 'Invocation deadline reached before fingerprint')
            need(self.active_read is None, 'Unexpected nested fingerprint')
            self.active_read = name
            self.active_identity = None
            self.active_path = None
            try:
                result = super().fingerprint(name)
                need('sha256' in result and self.active_path is not None, 'Required snapshot file missing: ' + name)
                before = self.active_identity
                need(before == stat_identity(self.active_path), 'File changed during actual helper read: ' + name)
                row = catalog_rows.get(name)
                need(row is None or before[0] == row['bytes'], 'Catalog file size changed: ' + name)
                self.metrics['fingerprint_calls'] += 1
                self.metrics['stable_fingerprint_reads'] += 1
                self.metrics['successful_fingerprint_bytes'] += before[0]
                self.read_counts[name] = self.read_counts.get(name, 0) + 1
                if name in protected:
                    self.metrics['protected_fingerprint_calls'] += 1
                    self.metrics['protected_fingerprint_bytes'] += before[0]
                if name.startswith('bin/') and name in protected:
                    self.metrics['bin_fingerprint_calls'] += 1
                    self.metrics['bin_fingerprint_bytes'] += before[0]
                if before[0] > self.metrics['largest_file_bytes']:
                    self.metrics['largest_file_bytes'] = before[0]
                    self.metrics['largest_file_path'] = name
                if self.metrics['protected_fingerprint_calls'] and self.metrics['protected_fingerprint_calls'] % 1000 == 0 and name in protected:
                    print(json.dumps({'event': 'protected_fingerprint_progress', 'completed': self.metrics['protected_fingerprint_calls'],
                                      'bytes': self.metrics['protected_fingerprint_bytes']}), flush=True)
                return result
            finally:
                self.active_read = None

        def state(self):
            if self.fixture_state is not None:
                return parse_state(self.fixture_state.read_bytes(), helper)
            return super().state()

        def journal(self, phase):
            if phase == '25' and self.fixture_journal is not None:
                return self.fixture_journal
            return super().journal(phase)

        def save(self, journal):
            raise RuntimeError('No helper journal mutation is permitted in this offline test')

    return ReadOnlyRepo()


def git_identity(repo, helper):
    index = Path(repo.text('rev-parse', '--git-path', 'index'))
    if not index.is_absolute():
        index = ROOT / index
    raw_state = helper.Repo.path(repo, helper.STATE).read_bytes()
    real_journal = helper.Repo.journal(repo, '25')
    real_receipt = ROOT / 'pre-editor-checkpoints/phase-25.json'
    need(not real_journal.exists() and not real_receipt.exists(), 'A real Phase25 seal/receipt exists; offline fixture must not coexist with it')
    main_sha = sha(helper.Repo.path(repo, MAIN).read_bytes())
    need(main_sha == PENDING_MAIN_SHA, 'Expected unresolved owner main.cpp bytes changed')
    return {'head': repo.text('rev-parse', 'HEAD'), 'branch': repo.text('branch', '--show-current'),
            'raw_index_sha256': sha(index.read_bytes()), 'logical_index_sha256': helper.index_identity(repo),
            'refs_sha256': sha(repo.git('show-ref', '--head')),
            'real_state_sha256': sha(raw_state), 'real_phase25_journal_absent': True,
            'real_phase25_receipt_absent': True, 'unadmitted_main_cpp_sha256': main_sha}


def junction_identity(protected, catalog):
    ancestors = set()
    for name in protected:
        path = ROOT / name
        ancestors.add(path)
        for parent in path.parents:
            if parent == ROOT:
                break
            ancestors.add(parent)
    found = {}
    for path in sorted(ancestors):
        info = path.lstat()
        if getattr(info, 'st_file_attributes', 0) & 0x400:
            resolved = path.resolve()
            need(resolved.is_relative_to(ROOT), 'Reparse point leaves the worktree: ' + str(path))
            found[rel(path)] = {'attributes': info.st_file_attributes,
                                'reparse_tag': getattr(info, 'st_reparse_tag', None),
                                'resolved': resolved.as_posix()}
    need(found == catalog['reparse_ancestors'], 'Actual reparse inventory/target differs from accepted catalog')
    return {'unique_paths_and_ancestors_inspected': len(ancestors), 'reparse_points': found,
            'aliases': 206, 'alias_logical_bytes': 491048891}


def make_fixture(repo, helper, spec, hashes, session, changed):
    receipt_path = session / 'fixture-receipt.json'
    journal_path = session / 'fixture-journal.json'
    state_path = session / 'fixture-state-after.md'
    snapshot_path = session / 'protected-snapshot.json'
    before_state, state = repo.state()
    need(state['Current approved phase'] == '24' and state['Next expected phase'] == '25', 'Actual state is not the unapproved Phase25 entry state')
    previous = repo.load('24')
    record = copy.deepcopy(previous['owner_mutable_after_seal'][CANONICAL])
    aliases = {}
    for field in ('validated_blob', 'blob'):
        real_ref = record[field + '_ref']
        virtual_ref = helper.blob_ref(repo, '25', CANONICAL, record[field])
        aliases[virtual_ref] = {'real_ref': real_ref, 'oid': record[field]}
        record[field + '_ref'] = virtual_ref
    protected = set(hashes)
    observed_other = changed - protected
    checkpoint = set(spec['checkpoint_files']) | observed_other | {rel(receipt_path)}
    local = (set(spec['local_governance']) | {helper.PHASE25_HANDOFF['authorization']}) - checkpoint - protected
    inputs = set(checkpoint) | local | set(spec['contract_files']) | set(helper.phase25_handoff_inputs()) | {SPEC, CANONICAL}
    inputs.discard(rel(receipt_path))
    for name in sorted(inputs - set(hashes)):
        hashes[name] = repo.fingerprint(name)
    need(hashes[CANONICAL] == record['fingerprint'], 'Actual canonical bytes do not match retained predecessor raw bytes')
    public = {
        'schema': 2, 'phase': '25', 'baseline': BASELINE, 'eligible': True,
        'summary': 'OFFLINE SYNTHETIC RECEIPT ONLY; NO REAL CANDIDATE ELIGIBILITY OR HUMAN ACCEPTANCE',
        'review': rel(receipt_path), 'next_phase': '26', 'previous_approved_tag': state['Current approved tag'],
        'branch': state['Refactor branch'], 'remote': state['Configured remote'],
        'checkpoint_files': sorted(checkpoint), 'local_governance': sorted(local), 'protected_files': sorted(protected),
        'validation_input_hashes': {CANONICAL: record['fingerprint']},
        'owner_mutable_after_seal': {CANONICAL: record}, 'baseline_handoff': copy.deepcopy(helper.PHASE25_HANDOFF),
        'validation': [{'check': 'OFFLINE_FIXTURE_ONLY', 'result': 'PASS',
                        'command': 'full_scale_offline.py capture', 'evidence': rel(snapshot_path)}],
        'findings': [], 'offline_test_only': True, 'actual_phase25_human_acceptance': 'PENDING',
        'actual_main_cpp_disposition': 'UNADMITTED; PRESERVE CURRENT BYTES',
    }
    write_new(receipt_path, helper.encode_json(public))
    hashes[rel(receipt_path)] = repo.fingerprint(rel(receipt_path))
    index_identity = helper.index_identity(repo)
    journal = {
        'schema': 2, 'phase': '25', 'status': 'PENDING', 'baseline': BASELINE,
        'receipt': rel(receipt_path), 'push_destination': repo.push_destination(state['Configured remote']),
        'state_before': base64.b64encode(before_state).decode(), 'state': state,
        'checkpoint_files': public['checkpoint_files'], 'local_governance': public['local_governance'],
        'protected_files': public['protected_files'], 'hashes': hashes,
        'owner_mutable_after_seal': public['owner_mutable_after_seal'], 'index_at_seal': index_identity,
        'transaction': None, 'offline_test_only': True,
    }
    after_state = helper.state_after(journal, public)
    journal['transaction'] = {'state_after': base64.b64encode(after_state).decode(),
                              'files': sorted(checkpoint), 'tree': None, 'commit': None,
                              'branch_pushed': False, 'tag_pushed': False, 'index_identity': index_identity}
    write_new(state_path, after_state)
    write_new(journal_path, helper.encode_json(journal))
    return {'journal': rel(journal_path), 'journal_sha256': sha(journal_path.read_bytes()),
            'receipt': rel(receipt_path), 'receipt_sha256': sha(receipt_path.read_bytes()),
            'state_after': rel(state_path), 'state_after_sha256': sha(after_state),
            'retention_ref_aliases': aliases,
            'observed_changed_paths_outside_protected': sorted(observed_other),
            'observed_paths_note': 'Fixture membership only; admitting these names does not authorize production scope or validate unadmitted main.cpp.',
            'full_snapshot_hashes': hashes}


def load_fixture(session, expected, helper_sha):
    path = session / 'protected-snapshot.json'
    raw = path.read_bytes()
    snapshot = json.loads(raw)
    need(encoded(snapshot) == raw, 'Serialized snapshot does not round-trip canonically')
    need(snapshot['catalog_sha256'] == CATALOG_SHA and snapshot['helper_sha256'] == helper_sha, 'Snapshot input binding changed')
    need(snapshot['protected_hashes'] == expected, 'Snapshot protected closure differs from the accepted exact inventory')
    fixture = snapshot['fixture']
    for field in ('journal', 'receipt', 'state_after'):
        target = output_path(fixture[field])
        need(target.is_relative_to(session), 'Fixture file leaves its isolated session')
        need(sha(target.read_bytes()) == fixture[field + '_sha256'], 'Serialized fixture changed: ' + field)
    journal = json.loads(output_path(fixture['journal']).read_bytes())
    need(journal['hashes'] == fixture['full_snapshot_hashes'], 'Journal/snapshot full closures differ')
    need(set(journal['protected_files']) == set(expected), 'Journal protected membership changed')
    need(all(journal['hashes'][p] == fp for p, fp in expected.items()), 'Journal protected hashes changed')
    return snapshot, journal, sha(raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('capture', 'check', 'recovery'))
    parser.add_argument('--session', required=True, help='New capture directory, or the same directory for later checks; inside tests only')
    parser.add_argument('--helper-sha256', required=True, help='Parent-pinned authorized implementation identity; not self-selected')
    parser.add_argument('--report', required=True, help='New immutable result path inside tests; use a new path for every attempt')
    parser.add_argument('--timeout-seconds', type=float, default=115.0)
    args = parser.parse_args()
    need(re.fullmatch('[0-9a-f]{64}', args.helper_sha256), 'A complete pinned helper SHA-256 is required')
    need(0 < args.timeout_seconds <= 115, 'Internal deadline must be at most 115 seconds, leaving parent timeout headroom')
    session = output_path(args.session)
    report_path = output_path(args.report)
    need(not report_path.exists(), 'Never overwrite prior test results')
    need(session != TEST_ROOT.resolve(), 'Use an isolated subdirectory for the fixture session')
    if args.mode == 'capture':
        need(not session.exists(), 'Capture requires a new session directory')
        session.mkdir(parents=True)
    else:
        need(session.is_dir(), 'Missing capture session')
    started = time.monotonic()
    deadline = started + args.timeout_seconds
    report = {'schema': 1, 'mode': args.mode, 'status': 'RUNNING', 'offline_only': True,
              'real_seal_finish_or_publication': False, 'actual_phase25_eligibility': 'NOT_ESTABLISHED',
              'helper_sha256': args.helper_sha256, 'test_script_sha256': sha(Path(__file__).read_bytes()),
              'invocation_timeout_seconds': args.timeout_seconds, 'cumulative_budget_owner': 'parent controller; 600 seconds total',
              'capability_limits': LIMITS}
    repo = None
    helper = None

    def timed_out():
        timeout_report = dict(report, status='TIMEOUT', seconds=time.monotonic() - started,
                              reason='Internal deadline; no retry or continuation was performed')
        if repo is not None:
            timeout_report['completed_read_metrics'] = dict(repo.metrics)
        try:
            timeout_report['windows_resources_after'] = windows_resources()
            write_new(report_path, encoded(timeout_report))
            print(json.dumps({'status': 'TIMEOUT', 'report': rel(report_path)}), flush=True)
        finally:
            os._exit(124)

    timer = threading.Timer(args.timeout_seconds, timed_out)
    timer.daemon = True
    timer.start()
    exit_code = 1
    try:
        report['windows_resources_before'] = windows_resources()
        helper_bytes = (ROOT / HELPER).read_bytes()
        need(sha(helper_bytes) == args.helper_sha256, 'Helper differs from parent-pinned authorized implementation')
        helper = types.ModuleType('phase25_fullscale_actual_helper')
        helper.__file__ = str(ROOT / HELPER)
        exec(compile(helper_bytes, helper.__file__, 'exec'), helper.__dict__)
        helper.configure_workflow('pre-editor')
        need(hasattr(helper, 'PHASE25_HANDOFF') and hasattr(helper, 'phase25_handoff_inputs'), 'Implemented Phase25 bridge is required')
        catalog_bytes = (ROOT / CATALOG).read_bytes()
        need(sha(catalog_bytes) == CATALOG_SHA, 'Accepted catalog changed')
        catalog = json.loads(catalog_bytes)
        rows = {r['path']: r for r in catalog['paths']}
        need(len(rows) == len(catalog['paths']) == 8042, 'Catalog membership is not the accepted unique 8042 entries')
        bin_rows = {p: r for p, r in rows.items() if p.startswith('bin/')}
        historical = {p: r for p, r in rows.items() if r['category'] == 'HISTORICAL_EVIDENCE_AND_INHERITED_WORK'}
        need(len(bin_rows) == 8028 and sum(r['bytes'] for r in bin_rows.values()) == 28151404975, 'Actual-size catalog count/bytes differ')
        need(len(historical) == 7, 'Historical protected membership differs')
        spec = json.loads((ROOT / SPEC).read_bytes())
        expected_original = set(historical) | set(GUARDS) | {HELPER}
        need(set(spec['protected_files']) == expected_original and len(spec['protected_files']) == 13, 'Original 13-path protected set changed')
        expected = {p: {'sha256': row['sha256'], 'executable': None} for p, row in {**bin_rows, **historical}.items()}
        expected.update({p: {'sha256': value, 'executable': None} for p, value in GUARDS.items()})
        expected[HELPER] = {'sha256': args.helper_sha256, 'executable': None}
        need(len(expected) == 8041 and not (set(expected) & set(spec['checkpoint_files'])), 'Protected count or ownership overlap mismatch')
        protected = set(expected)
        repo = make_repo(helper, rows, protected, deadline)
        report['git_before'] = git_identity(repo, helper)
        need(report['git_before']['head'] == BASELINE and report['git_before']['branch'] == 'pre-editor/refactor', 'Unexpected actual worktree baseline/branch')
        report['junction_before'] = junction_identity(protected, catalog)
        report['protected_count'] = len(protected)
        report['bin_count'] = len(bin_rows)
        report['expected_bin_logical_bytes'] = 28151404975
        changed_before = repo.changed()
        if args.mode == 'capture':
            hashes = {}
            for name in sorted(protected):
                hashes[name] = repo.fingerprint(name)
                need(hashes[name] == expected[name], 'Accepted preservation identity changed: ' + name)
            fixture = make_fixture(repo, helper, spec, dict(hashes), session, changed_before)
            snapshot = {'schema': 1, 'offline_test_only': True, 'catalog_sha256': CATALOG_SHA,
                        'helper_sha256': args.helper_sha256, 'protected_hashes': hashes, 'fixture': fixture,
                        'git_at_capture': report['git_before'], 'junction_at_capture': report['junction_before']}
            snapshot_path = session / 'protected-snapshot.json'
            write_new(snapshot_path, encoded(snapshot))
            loaded, journal, snapshot_sha = load_fixture(session, expected, args.helper_sha256)
            need(loaded == snapshot, 'Full serialized capture differs from in-memory capture')
            report['operation'] = 'Real Repo.path/fingerprint capture and accepted-catalog comparison; serialized full snapshot/journal/receipt round-trip'
        else:
            snapshot, journal, snapshot_sha = load_fixture(session, expected, args.helper_sha256)
            need(snapshot['git_at_capture'] == report['git_before'], 'Git/index/state/main identities changed since capture')
            need(snapshot['junction_at_capture'] == report['junction_before'], 'Junction changed since capture')
            if args.mode == 'check':
                helper.check_hashes(repo, journal['hashes'])
                report['operation'] = 'Actual check_hashes over the complete serialized/reloaded closure; all protected bytes reread'
            else:
                fixture = snapshot['fixture']
                repo.fixture_state = output_path(fixture['state_after'])
                repo.fixture_journal = output_path(fixture['journal'])
                repo.aliases = fixture['retention_ref_aliases']
                current_state = repo.state()[1]
                need(current_state['Current approved phase'] == '25' and current_state['Next expected phase'] == '26', 'Fixture does not represent advanced pending state')
                need(journal['state']['Current approved phase'] == '24' and journal['state']['Next expected phase'] == '25', 'Original journal state changed')
                public = helper.check(repo, repo.load('25'), pending=True)
                need(public['offline_test_only'] is True and public['actual_phase25_human_acceptance'] == 'PENDING', 'Fixture labeling changed')
                report['operation'] = 'Actual pending check with all real protected hashes, original journal state, advanced fixture state, real predecessor gate and retained raw/filtered Git blobs'
                report['retention_ref_aliases'] = repo.aliases
                report['pending_recovery_uses_original_state'] = True
                report['transaction_side_effects_executed'] = False
        report['snapshot_sha256'] = snapshot_sha
        report['full_snapshot_file_count'] = len(journal['hashes'])
        report['junction_after'] = junction_identity(protected, catalog)
        need(report['junction_before'] == report['junction_after'], 'Junction/ancestor inventory changed during full scan')
        need(changed_before == repo.changed(), 'Real changed-path membership changed during invocation')
        need(all(repo.read_counts.get(p) == 1 for p in protected), 'Each protected file must be fingerprinted exactly once in this invocation')
        need(repo.metrics['bin_fingerprint_calls'] == 8028 and repo.metrics['bin_fingerprint_bytes'] == 28151404975, 'Actual full bin bytes were not all read')
        report['git_after'] = git_identity(repo, helper)
        need(report['git_before'] == report['git_after'], 'Real Git/index/state/main identities changed during test')
        need(sha((ROOT / HELPER).read_bytes()) == args.helper_sha256, 'Helper changed during invocation')
        report['status'] = 'PASS'
        exit_code = 0
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = str(error)
        report['traceback'] = traceback.format_exc()
    finally:
        timer.cancel()
        report['seconds'] = time.monotonic() - started
        report['process_cpu_seconds'] = {'user': os.times().user, 'system': os.times().system}
        try:
            report['windows_resources_after'] = windows_resources()
        except Exception as error:
            report['resource_reporting_error'] = str(error)
            report['status'] = 'FAIL'
            exit_code = 1
        if repo is not None:
            report['read_metrics'] = repo.metrics
            report['read_only_git_calls'] = repo.git_calls
            if report.get('status') != 'PASS' and helper is not None:
                try:
                    report['git_after_failure'] = git_identity(repo, helper)
                except Exception as error:
                    report['git_after_failure_error'] = str(error)
        report['result_path'] = rel(report_path)
        write_new(report_path, encoded(report))
        print(json.dumps({'status': report['status'], 'mode': args.mode, 'seconds': report['seconds'],
                          'protected_files_read': report.get('read_metrics', {}).get('protected_fingerprint_calls', 0),
                          'bin_bytes_read': report.get('read_metrics', {}).get('bin_fingerprint_bytes', 0),
                          'peak_working_set_bytes': report.get('windows_resources_after', {}).get('memory_bytes', {}).get('PeakWorkingSetSize'),
                          'report': rel(report_path)}), flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
