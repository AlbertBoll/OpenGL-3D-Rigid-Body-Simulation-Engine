#!/usr/bin/env python3
"""Finite, offline Phase25 publication-guard regression suite.

The runner must impose the accepted 120 s/invocation and 600 s/cumulative limits.
This file never invokes a Git subprocess.  All seal/finish calls below receive an
in-memory repository, with in-memory objects, refs, journals, index, and writes.
Named accepted inputs are read once to supply realistic pinned fixture bytes.
No source, real index/ref, application, build, or measurement is mutated/run.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


TEST_DIR = Path(__file__).resolve().parent
WORKSPACE = TEST_DIR.parents[4]
DEFAULT_HELPER = WORKSPACE / ".codex/tools/rendering_checkpoint.py"
DEFAULT_BEFORE = TEST_DIR.parent / "before/helper.py"
PARSER = argparse.ArgumentParser(add_help=False)
PARSER.add_argument("--helper", type=Path, default=DEFAULT_HELPER)
PARSER.add_argument("--before", type=Path, default=DEFAULT_BEFORE)
OPTIONS, UNITTEST_ARGS = PARSER.parse_known_args()
sys.dont_write_bytecode = True


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


HELPER = load_module(OPTIONS.helper, "phase25_checkpoint_under_test")
BEFORE = load_module(OPTIONS.before, "phase25_checkpoint_before") if OPTIONS.before.is_file() else None
CANONICAL = "RigidBodySimulation/src/RigidBodySimulation.cpp"
MAIN = "RigidBodySimulation/src/main.cpp"
AUTHORIZATION = "docs/pre_editor/active/PHASE_25_PUBLICATION_GUARD_AUTHORIZATION_01.json"
ACCEPTANCE = "logs/pre_editor/collider-c04-r05-closure-20261102-01/OWNER_FINAL_ACCEPTANCE.json"
INTEGRATED = "logs/pre_editor/collider-c04-r05-closure-20261102-01/INTEGRATED_51_FILES.json"
PROPOSAL_ROOT = "docs/pre_editor/proposals/PHASE_25_FINAL_PUBLICATION_GUARD_RESOLUTION_01/"
PREVIOUS_COMMIT = "118e4e1e544ef2e26ec5930cd9c7f56a8cf6b0d3"
PREVIOUS_TAG = "pre-editor-phase-24-approved"
PREVIOUS_TAG_OBJECT = "b84e3ee2dfef7b4c60f7d5ddfa749dbaa4e1ec0f"
BASELINE = "871e065c53cb7364d2e8091dfff7e0080db14869"
BASELINE_TREE = "48132991293d5a840089236c2b177195f74bf872"
COLLIDER_TAG = "collider-c04-r05-integrated-owner-accepted"
COLLIDER_TAG_OBJECT = "d8dac4e04891e24fbdd715fcd545d003aad657ce"
DESTINATION = "https://github.com/AlbertBoll/OpenGL-3D-Rigid-Body-Simulation-Engine.git"
PREVIOUS_JOURNAL_SHA256 = "2d22af2d19adcc3866fda785ec2f8822b75e899cfac62daec7f85d7c0149e517"
PREVIOUS_RECEIPT_SHA256 = "c181d6970c35042768b91a4e8cecaf348be43d45b6dde1f9a8da99ee25d2721c"
ACCEPTANCE_SHA256 = "1e3990e53981b87224cdac90fe772961e893dcb517a6d14c6e5f45e042085653"
INTEGRATED_SHA256 = "746689c156b73f62c228571ec5cf3f8340fe11f42e2a8eaaa677efbc7b337bd9"
PROTECTED = "bin/Release/example/assets/retained.obj"
SOURCE = "GEngine/src/mock_phase25_source.cpp"
REVIEW = "docs/pre_editor/evidence/mock-phase25-review.md"
EVIDENCE = "logs/pre_editor/phase-25/mock-focused-PASS.json"
CONTRACT = "docs/pre_editor/phases/PHASE_25.md"


def read_pinned_inputs():
    """Read an explicit tiny metadata closure, never discover source/output trees."""
    paths = {
        AUTHORIZATION, ACCEPTANCE, INTEGRATED,
        "docs/pre_editor/active/ACTIVATION.json",
        "pre-editor-checkpoints/phase-24.json",
        PROPOSAL_ROOT + "PROPOSAL.md",
        PROPOSAL_ROOT + "path-classification.json",
        PROPOSAL_ROOT + "provenance.json",
        PROPOSAL_ROOT + "audit-closure.json",
        "docs/pre_editor/evidence/phase-22-publication-exception.json",
        "docs/pre_editor/evidence/phase-21-freeze.json",
    }

    def collect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                collect(key)
                collect(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                collect(item)
        elif isinstance(value, str) and value.startswith(("docs/", "logs/", "pre-editor-checkpoints/")):
            if value.endswith((".json", ".md")):
                paths.add(value)

    collect(getattr(HELPER, "PHASE25_HANDOFF", {}))
    values = {}
    for rel in sorted(paths):
        path = WORKSPACE / rel
        if path.is_file():
            values[rel] = path.read_bytes()
    before_dir = OPTIONS.before.parent
    for rel, name in {
        "_journals/PHASE_24.json": "PHASE_24.journal.json",
        "pre-editor-checkpoints/phase-24.json": "phase-24.receipt.json",
        ACCEPTANCE: "OWNER_FINAL_ACCEPTANCE.json", INTEGRATED: "INTEGRATED_51_FILES.json",
    }.items():
        values[rel] = (before_dir / name).read_bytes()
    return values


PINNED_INPUTS = None


class MemoryPath:
    """Only in-memory data are writable, including atomic/journal writes."""
    def __init__(self, repo, rel):
        self.repo = repo
        self.rel = rel

    def __str__(self):
        return str(self.repo.root / self.rel)

    @property
    def parent(self):
        return MemoryPath(self.repo, str(PurePosixPath(self.rel).parent))

    def glob(self, pattern):
        prefix = self.rel.rstrip("/") + "/"
        return [MemoryPath(self.repo, rel) for rel in sorted(self.repo.files)
                if rel.startswith(prefix) and PurePosixPath(rel).name.startswith("PHASE_")
                and rel.endswith(".json") and "/" not in rel[len(prefix):]]

    def exists(self):
        return self.rel in self.repo.files

    def is_file(self):
        return self.exists() and self.rel not in self.repo.nonregular

    def read_bytes(self):
        if self.rel not in self.repo.files:
            raise FileNotFoundError(self.rel)
        return self.repo.files[self.rel]

    def read_text(self, encoding="utf-8"):
        return self.read_bytes().decode(encoding)

    def write_bytes(self, data):
        self.repo.files[self.rel] = bytes(data)
        self.repo.memory_writes.append(self.rel)
        return len(data)

    def stat(self):
        if not self.exists():
            raise FileNotFoundError(self.rel)
        return SimpleNamespace(st_mode=stat.S_IFREG | self.repo.file_modes.get(self.rel, 0o644),
                               st_file_attributes=0x400 if self.rel in self.repo.reparse else 0)

    lstat = stat


class MemoryRepo:
    """Git-compatible state machine; does not inherit or call Repo.git."""
    def __init__(self, helper=HELPER):
        self.helper = helper
        self.root = WORKSPACE.resolve()
        self.files = dict(PINNED_INPUTS)
        self.nonregular = set()
        self.reparse = set()
        self.file_modes = {}
        self.memory_writes = []
        self.calls = []
        self.fail_once = None
        self.branch = "pre-editor/refactor"
        self.remotes = ["origin"]
        self.destination = DESTINATION
        self.head = BASELINE
        self.parents = {BASELINE: PREVIOUS_COMMIT, PREVIOUS_COMMIT: "0" * 40}
        self.trees = {BASELINE: BASELINE_TREE}
        self.refs = {
            "refs/tags/" + PREVIOUS_TAG: PREVIOUS_TAG_OBJECT,
            "refs/tags/" + COLLIDER_TAG: COLLIDER_TAG_OBJECT,
        }
        self.peels = {
            "refs/tags/" + PREVIOUS_TAG: PREVIOUS_COMMIT,
            "refs/tags/" + COLLIDER_TAG: BASELINE,
        }
        self.types = {PREVIOUS_TAG_OBJECT: "tag", COLLIDER_TAG_OBJECT: "tag",
                      BASELINE: "commit", PREVIOUS_COMMIT: "commit"}
        self.objects = {}
        self.remote_refs = {}
        self.index = {}
        self.head_index = {}
        self.baseline_index = {}
        self.tracked_paths = {"pre-editor-checkpoints/phase-24.json"}
        self.ignored_paths = set(self.files) - self.tracked_paths
        self.changed_paths = set()
        self.state_fields = {
            "Refactor branch": "pre-editor/refactor", "Configured remote": "origin",
            "Current approved phase": "24", "Current approved tag": PREVIOUS_TAG,
            "Next expected phase": "25", "Last approved review": "phase24-review.md",
        }
        self.set_state(self.state_fields)

    @staticmethod
    def oid(data):
        return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

    def path(self, rel):
        self.helper.require(isinstance(rel, str) and rel and "\\" not in rel and "\x00" not in rel,
                            "Invalid mock fixture relative path")
        pp = PurePosixPath(rel)
        self.helper.require(not pp.is_absolute() and ".." not in pp.parts and ":" not in rel,
                            "Unsafe mock fixture relative path")
        return MemoryPath(self, rel)

    def fingerprint(self, rel):
        if rel not in self.files:
            return {"absent": True}
        return {"sha256": self.helper.digest(self.files[rel]),
                "executable": None if os.name == "nt" else bool(self.file_modes.get(rel, 0o644) & 0o111)}

    def journal(self, phase):
        return self.path("_journals/PHASE_" + phase + ".json")

    def load(self, phase):
        return json.loads(self.journal(phase).read_text())

    def save(self, value):
        self.journal(value["phase"]).write_bytes(self.helper.encode_json(value))

    def set_state(self, fields):
        self.state_fields = dict(fields)
        self.files[self.helper.STATE] = ("# Mock state\r\n" + "".join(
            "- " + key + ": `" + value + "`\r\n" for key, value in fields.items())).encode()

    def state(self):
        return self.helper.Repo.state(self)

    def tracked(self, rel):
        return rel in self.tracked_paths

    def ignored(self, rel):
        return rel in self.ignored_paths

    def push_destination(self, remote):
        self.helper.require(remote in self.remotes, "Mock remote missing")
        return self.destination

    def changed(self):
        return set(self.changed_paths)

    def staged(self):
        keys = set(self.index) | set(self.head_index)
        return {key for key in keys if self.index.get(key, ())[:3] != self.head_index.get(key, ())[:3]}

    def add_file(self, rel, data, tracked=False, changed=False, ignored=False):
        self.files[rel] = bytes(data)
        if tracked:
            self.tracked_paths.add(rel)
            oid = self.oid(data)
            self.objects[oid] = bytes(data)
            self.types[oid] = "blob"
            self.index[rel] = ("100644", oid, "0", "H")
            self.head_index[rel] = self.index[rel]
            self.baseline_index[rel] = self.index[rel]
        if changed:
            self.changed_paths.add(rel)
        if ignored:
            self.ignored_paths.add(rel)
        else:
            self.ignored_paths.discard(rel)

    def text(self, *args):
        return self.git(*args).decode("utf-8").strip()

    def names(self, *args):
        return {os.fsdecode(item) for item in self.git(*args).split(b"\0") if item}

    def _resolve(self, name):
        if name == "HEAD":
            return self.head
        if name.endswith("^{commit}"):
            key = name[:-9]
            if not key.startswith("refs/"):
                key = "refs/tags/" + key
            if key not in self.refs:
                raise self.helper.Blocked("Missing mock tag " + key)
            return self.peels.get(key, self.refs[key])
        if name.endswith("^{tree}"):
            return self.trees[self._resolve(name[:-7])]
        if ":" in name and not name.startswith("refs/"):
            commit, path = name.split(":", 1)
            if commit == BASELINE:
                return self.baseline_index[path][1]
            return self.head_index[path][1]
        if name in self.refs:
            return self.refs[name]
        if "refs/tags/" + name in self.refs:
            return self.refs["refs/tags/" + name]
        if name in self.types or name in self.parents:
            return name
        raise self.helper.Blocked("Unknown mock identity " + name)

    def git(self, *args, input=None, allow_failure=False):
        self.calls.append(tuple(args))
        command = args[0]
        if self.fail_once == command or self.fail_once == tuple(args):
            self.fail_once = None
            raise self.helper.Blocked("Injected interrupted mock " + command)
        rc = 0
        out = b""
        if command == "rev-parse":
            out = self._resolve(args[-1]).encode()
        elif command == "branch":
            out = self.branch.encode()
        elif command == "remote":
            out = (self.destination if len(args) > 1 else "\n".join(self.remotes)).encode()
        elif command == "show":
            out = self.parents[args[-1]].encode()
        elif command == "cat-file":
            oid = self._resolve(args[-1])
            out = (self.types[oid].encode() if args[1] == "-t" else self.objects[oid])
        elif command == "hash-object":
            oid = self.oid(input)
            if "-w" in args:
                self.objects[oid] = bytes(input)
                self.types[oid] = "blob"
            out = oid.encode()
        elif command == "show-ref":
            target = self.refs.get(args[-1])
            rc = 0 if target is not None else 1
            out = target.encode() if target and "--quiet" not in args else b""
        elif command == "update-ref":
            ref, oid, prior = args[1:]
            self.helper.require(ref not in self.refs and set(prior) == {"0"}, "Mock retention ref collision")
            self.refs[ref] = oid
        elif command == "ls-tree":
            rel = args[-1]
            entry = self.baseline_index.get(rel)
            if entry:
                out = (entry[0] + " blob " + entry[1] + "\t" + rel + "\0").encode()
        elif command == "ls-files":
            selected = {args[-1]} if "--" in args else set(self.index)
            records = []
            for rel in sorted(selected):
                if rel not in self.index:
                    continue
                mode, oid, stage, flag = self.index[rel]
                if "-u" in args and stage == "0":
                    continue
                if "-v" in args:
                    records.append(flag + " " + rel + "\0")
                else:
                    records.append(mode + " " + oid + " " + stage + "\t" + rel + "\0")
            out = "".join(records).encode()
        elif command == "diff":
            if "--name-only" in args:
                values = self.staged() if "--cached" in args else self.changed()
                out = "".join(path + "\0" for path in sorted(values)).encode()
        elif command == "check-ignore":
            rc = 0 if self.ignored(args[-1]) else 1
        elif command == "config":
            out = b"false"
        elif command == "check-ref-format":
            pass
        elif command == "add":
            for rel in args[2:]:
                if rel not in self.files:
                    self.index.pop(rel, None)
                    continue
                oid = self.oid(self.files[rel])
                self.objects[oid] = self.files[rel]
                self.types[oid] = "blob"
                self.index[rel] = ("100644", oid, "0", "H")
        elif command == "update-index":
            mode, oid, rel = args[-3:]
            self.index[rel] = (mode, oid, "0", "H")
        elif command == "write-tree":
            out = hashlib.sha1(repr(sorted(self.index.items())).encode()).hexdigest().encode()
        elif command == "commit":
            tree = hashlib.sha1(repr(sorted(self.index.items())).encode()).hexdigest()
            previous = self.head
            self.head = hashlib.sha1((tree + previous + args[-1]).encode()).hexdigest()
            self.parents[self.head] = previous
            self.trees[self.head] = tree
            self.types[self.head] = "commit"
            self.changed_paths -= self.staged()
            self.head_index = dict(self.index)
            self.tracked_paths |= set(self.index)
        elif command == "tag":
            self.helper.require(args[1] == "-a", "Only annotated mock tags supported")
            name, commit = args[2:4]
            ref = "refs/tags/" + name
            self.helper.require(ref not in self.refs, "Mock tag replacement prohibited")
            oid = hashlib.sha1((name + commit).encode()).hexdigest()
            self.refs[ref] = oid
            self.peels[ref] = commit
            self.types[oid] = "tag"
        elif command == "push":
            source, target = args[-1].split(":", 1)
            self.remote_refs[target] = self._resolve(source)
            if source.startswith("refs/tags/"):
                self.remote_refs[target + "^{}"] = self.peels[source]
        elif command == "ls-remote":
            out = "".join(self.remote_refs[ref] + "\t" + ref + "\n"
                          for ref in args[3:] if ref in self.remote_refs).encode()
        else:
            raise AssertionError("Unexpected mock Git command; no subprocess fallback: " + repr(args))
        if allow_failure:
            return SimpleNamespace(returncode=rc, stdout=out, stderr=b"")
        if rc:
            raise self.helper.Blocked("Mock Git command failed: " + repr(args))
        return out


def atomic_memory(path, data):
    if not isinstance(path, MemoryPath):
        raise AssertionError("An attempted helper write escaped the in-memory fixture")
    path.write_bytes(data)


def standard_spec(repo):
    """Small complete fixture, not a real candidate or acceptance declaration."""
    h = repo.helper
    repo.add_file(CANONICAL, b"// mock canonical qualified bytes\n", tracked=True)
    repo.add_file(SOURCE, b"// mock source before\n", tracked=True, changed=True)
    repo.files[SOURCE] = b"// mock source after\n"
    repo.add_file(REVIEW, b"Mock review, no real approval.\n", changed=True)
    repo.add_file(PROTECTED, b"# text mesh retained in place\n", changed=True)
    repo.add_file(EVIDENCE, b'{"result":"PASS","fixture":true}\n', ignored=True)
    repo.add_file(CONTRACT, b"# PRE_EDITOR Phase 25 mock contract\n", tracked=True)
    repo.add_file(h.VALIDATION_POLICY, b"Mock validation contract.\n", tracked=True)
    repo.add_file(h.PUBLICATION_POLICY, h.encode_json({
        "schema": 1, "enabled": True,
        "repository": "AlbertBoll/OpenGL-3D-Rigid-Body-Simulation-Engine",
        "branch": "pre-editor/refactor", "tag_template": "pre-editor-phase-{phase}-approved",
    }), ignored=True)
    repo.ignored_paths.add(AUTHORIZATION)
    required = HELPER.phase25_handoff_inputs()
    return {
        "phase": "25", "baseline": BASELINE, "summary": "offline mock fixture",
        "review": REVIEW, "checkpoint_files": [CANONICAL, SOURCE, REVIEW],
        "local_governance": [AUTHORIZATION, EVIDENCE], "protected_files": [PROTECTED],
        "contract_files": [CONTRACT, h.VALIDATION_POLICY, *sorted(required)],
        "validation_input_hashes": {p: repo.fingerprint(p) for p in (CANONICAL, SOURCE, EVIDENCE, *required)},
        "validation": [{"check": "mock invariant", "result": "PASS", "command": "mock-only", "evidence": EVIDENCE}],
    }


class OfflineCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        global PINNED_INPUTS
        if PINNED_INPUTS is None:
            PINNED_INPUTS = read_pinned_inputs()

    def setUp(self):
        HELPER.configure_workflow("pre-editor")
        if BEFORE:
            BEFORE.configure_workflow("pre-editor")
        self.no_run = patch.object(subprocess, "run", side_effect=AssertionError("Subprocess execution forbidden in offline tests"))
        self.no_popen = patch.object(subprocess, "Popen", side_effect=AssertionError("Subprocess execution forbidden in offline tests"))
        self.atomic = patch.object(HELPER, "atomic", atomic_memory)
        self.no_run.start()
        self.no_popen.start()
        self.atomic.start()
        self.addCleanup(self.no_run.stop)
        self.addCleanup(self.no_popen.stop)
        self.addCleanup(self.atomic.stop)
        self.repo = MemoryRepo()

    def reject(self, operation, pattern=None):
        if pattern:
            with self.assertRaisesRegex((HELPER.Blocked, FileNotFoundError), pattern):
                operation()
        else:
            with self.assertRaises((HELPER.Blocked, FileNotFoundError)):
                operation()

    def gate(self, repo=None, phase="25", baseline=BASELINE, state=None):
        repo = repo or self.repo
        return HELPER.phase25_accepted_collider_gate(repo, phase, baseline, state or repo.state_fields)

    def seal_mock(self, repo=None, spec=None):
        repo = repo or self.repo
        spec = spec or standard_spec(repo)
        result = HELPER.seal(repo, spec)
        self.assertEqual("SEALED", result["status"])
        return repo.load("25")

    def public(self, m, repo=None):
        return json.loads((repo or self.repo).files[m["receipt"]])

    def rewrite_public(self, m, public, repo=None):
        repo = repo or self.repo
        repo.files[m["receipt"]] = HELPER.encode_json(public)
        # Deliberately refresh only this fixture snapshot to isolate semantic
        # receipt checks from the independently tested snapshot mismatch gate.
        m["hashes"][m["receipt"]] = repo.fingerprint(m["receipt"])

    def pending_mock(self, postcommit=False):
        m = self.seal_mock()
        public = self.public(m)
        after = HELPER.state_after(m, public)
        m["status"] = "PENDING"
        m["transaction"] = {
            "state_after": base64.b64encode(after).decode(), "files": m["checkpoint_files"],
            "tree": None, "commit": None, "branch_pushed": False, "tag_pushed": False,
            "index_identity": HELPER.index_identity(self.repo),
        }
        if postcommit:
            self.repo.head = "a" * 40
            self.repo.parents[self.repo.head] = BASELINE
            self.repo.trees[self.repo.head] = "b" * 40
            self.repo.types[self.repo.head] = "commit"
            m["transaction"]["commit"] = self.repo.head
            m["transaction"]["tree"] = self.repo.trees[self.repo.head]
            self.repo.files[HELPER.STATE] = after
        return m


class ExactBridgeTests(OfflineCase):
    def test_accepted_literals_and_archived_bytes_are_exact(self):
        expected = json.loads(self.repo.files[AUTHORIZATION])["exact_bridge"]
        for key, value in expected.items():
            with self.subTest(key=key):
                self.assertEqual(value, HELPER.PHASE25_HANDOFF[key])
        for rel, expected_hash in {
            "_journals/PHASE_24.json": PREVIOUS_JOURNAL_SHA256,
            "pre-editor-checkpoints/phase-24.json": PREVIOUS_RECEIPT_SHA256,
            ACCEPTANCE: ACCEPTANCE_SHA256, INTEGRATED: INTEGRATED_SHA256,
            AUTHORIZATION: "86122ea13fa07ff07031d26c251a2df3475d79baeb2963ff957f9d1a90b13fd5",
        }.items():
            with self.subTest(path=rel):
                self.assertEqual(expected_hash, HELPER.digest(self.repo.files[rel]))
        self.assertIsNotNone(BEFORE, "Preserved helper is mandatory for regression comparison")
        self.assertEqual("76957e3d6a9a4dfdbe284bd17cbf27cbd567ad4e2134ae06c5db4f5828e66d75",
                         HELPER.digest(OPTIONS.before.read_bytes()))

    def test_exact_accepted_tuple_passes_without_mutation(self):
        files = dict(self.repo.files)
        refs = dict(self.repo.refs)
        self.gate()
        HELPER.baseline_gate(self.repo, "25", BASELINE, self.repo.state_fields)
        self.assertEqual(files, self.repo.files)
        self.assertEqual(refs, self.repo.refs)
        self.assertFalse(self.repo.memory_writes)
        self.assertFalse(any(call[0] == "merge-base" for call in self.repo.calls))

    def test_bridge_rejects_other_workflows_and_phases(self):
        for phase in ("00", "22", "24", "26", "55"):
            with self.subTest(phase=phase):
                self.reject(lambda: self.gate(phase=phase))
        HELPER.configure_workflow("rendering")
        self.reject(self.gate)

    def test_exact_state_root_branch_and_remote_are_mandatory(self):
        changes = {
            "Current approved phase": "25", "Current approved tag": "pre-editor-phase-23-approved",
            "Next expected phase": "26", "Refactor branch": "pre-editor/other", "Configured remote": "mirror",
        }
        for field, value in changes.items():
            with self.subTest(field=field):
                state = dict(self.repo.state_fields, **{field: value})
                self.reject(lambda: self.gate(state=state))
        self.repo.root = WORKSPACE.parent / "wrong-worktree"
        self.reject(self.gate)

    def test_common_head_branch_remote_and_expected_phase_checks_remain(self):
        for kind in ("head", "branch", "remote", "next"):
            with self.subTest(kind=kind):
                repo = MemoryRepo()
                if kind == "head":
                    repo.head = "a" * 40
                elif kind == "branch":
                    repo.branch = "pre-editor/other"
                elif kind == "remote":
                    repo.remotes = []
                else:
                    repo.state_fields["Next expected phase"] = "26"
                self.reject(lambda: HELPER.baseline_gate(repo, "25", BASELINE, repo.state_fields))

    def test_descendant_sibling_cherry_pick_and_merge_baselines_are_rejected(self):
        for kind, candidate, parents in (
            ("descendant", "a" * 40, BASELINE),
            ("sibling", "b" * 40, PREVIOUS_COMMIT),
            ("cherry-pick", "c" * 40, PREVIOUS_COMMIT),
            ("merge", "d" * 40, PREVIOUS_COMMIT + " " + BASELINE),
        ):
            with self.subTest(kind=kind):
                repo = MemoryRepo()
                repo.head = candidate
                repo.parents[candidate] = parents
                repo.trees[candidate] = BASELINE_TREE
                self.reject(lambda: self.gate(repo, baseline=candidate))

    def test_accepted_commit_wrong_tree_or_parent_is_rejected(self):
        for kind, value in (("tree", "a" * 40), ("parent", "b" * 40),
                            ("merge", PREVIOUS_COMMIT + " " + "c" * 40), ("root", "")):
            with self.subTest(kind=kind):
                repo = MemoryRepo()
                if kind == "tree":
                    repo.trees[BASELINE] = value
                else:
                    repo.parents[BASELINE] = value
                self.reject(lambda: self.gate(repo))

    def test_missing_lightweight_replaced_or_wrongly_peeled_tags_are_rejected(self):
        for tag in (PREVIOUS_TAG, COLLIDER_TAG):
            for fault in ("missing", "lightweight", "replaced", "peeled"):
                with self.subTest(tag=tag, fault=fault):
                    repo = MemoryRepo()
                    ref = "refs/tags/" + tag
                    if fault == "missing":
                        del repo.refs[ref]
                    elif fault == "lightweight":
                        repo.types[repo.refs[ref]] = "commit"
                    elif fault == "replaced":
                        repo.refs[ref] = "e" * 40
                        repo.types["e" * 40] = "tag"
                    else:
                        repo.peels[ref] = "f" * 40
                    self.reject(lambda: self.gate(repo))

    def test_missing_and_altered_all_pinned_authority_and_evidence_files_reject(self):
        for rel in HELPER.phase25_handoff_inputs():
            for fault in ("missing", "altered"):
                with self.subTest(path=rel, fault=fault):
                    repo = MemoryRepo()
                    if fault == "missing":
                        del repo.files[rel]
                    else:
                        repo.files[rel] += b"\nunauthorized change\n"
                    self.reject(lambda: self.gate(repo))

    def test_missing_altered_or_invalid_json_predecessor_journal_rejects(self):
        for replacement in (None, b"{}\n", b"not-json\n"):
            with self.subTest(replacement=replacement):
                repo = MemoryRepo()
                if replacement is None:
                    del repo.files["_journals/PHASE_24.json"]
                else:
                    repo.files["_journals/PHASE_24.json"] = replacement
                self.reject(lambda: self.gate(repo))

    def test_predecessor_semantics_fail_even_with_a_synthetic_matching_journal_pin(self):
        # The production pin never changes; changing it temporarily here isolates
        # semantic guard coverage from the independently tested raw-byte pin.
        mutations = (
            ("status", "PENDING"), ("receipt", "pre-editor-checkpoints/phase-23.json"),
            ("push_destination", "https://example.invalid/wrong.git"),
            ("transaction.commit", "a" * 40), ("transaction.branch_pushed", False),
            ("transaction.tag_pushed", False), ("transaction", None),
        )
        for field, value in mutations:
            with self.subTest(field=field):
                repo = MemoryRepo()
                prior = repo.load("24")
                if "." in field:
                    outer, inner = field.split(".")
                    prior[outer][inner] = value
                else:
                    prior[field] = value
                raw = HELPER.encode_json(prior)
                repo.files["_journals/PHASE_24.json"] = raw
                with patch.dict(HELPER.PHASE25_HANDOFF, {"previous_journal_sha256": HELPER.digest(raw)}):
                    self.reject(lambda: self.gate(repo))

    def test_changed_push_destination_rejects_without_remote_contact(self):
        self.repo.destination = "https://github.com/other/repository.git"
        self.reject(self.gate)
        self.assertFalse(any(call[0] in ("push", "ls-remote") for call in self.repo.calls))

    def test_predecessor_receipt_must_remain_tracked(self):
        self.repo.tracked_paths.remove("pre-editor-checkpoints/phase-24.json")
        self.reject(self.gate)


class SnapshotAndReceiptTests(OfflineCase):
    def test_mock_seal_records_exact_handoff_and_all_required_bindings(self):
        m = self.seal_mock()
        public = self.public(m)
        self.assertEqual(2, m["schema"])
        self.assertEqual(2, public["schema"])
        self.assertEqual(HELPER.PHASE25_HANDOFF, public["baseline_handoff"])
        for rel, sha in HELPER.phase25_handoff_inputs().items():
            with self.subTest(path=rel):
                self.assertEqual(sha, m["hashes"][rel]["sha256"])
        self.assertEqual(public, HELPER.check(self.repo, m))
        self.assertIn(PROTECTED, m["hashes"])
        self.assertNotIn(PROTECTED, m["checkpoint_files"])

    def test_authority_must_be_bound_at_seal_not_merely_present_on_disk(self):
        for rel in HELPER.phase25_handoff_inputs():
            with self.subTest(path=rel):
                repo = MemoryRepo()
                spec = standard_spec(repo)
                for key in ("checkpoint_files", "local_governance", "protected_files", "contract_files"):
                    spec[key] = [p for p in spec[key] if p != rel]
                spec["validation_input_hashes"].pop(rel, None)
                self.reject(lambda: HELPER.seal(repo, spec))
                self.assertNotIn("_journals/PHASE_25.json", repo.files)

    def test_missing_or_substituted_authority_snapshot_rejects(self):
        for fault in ("missing", "sha", "absent"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                if fault == "missing":
                    del m["hashes"][AUTHORIZATION]
                elif fault == "sha":
                    m["hashes"][AUTHORIZATION]["sha256"] = "0" * 64
                else:
                    m["hashes"][AUTHORIZATION] = {"absent": True}
                self.reject(lambda: HELPER.check(repo, m))

    def test_missing_modified_or_extra_receipt_handoff_rejects(self):
        for fault in ("missing", "baseline", "tag", "authorization", "extra"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                public = self.public(m, repo)
                if fault == "missing":
                    del public["baseline_handoff"]
                elif fault == "extra":
                    public["baseline_handoff"]["override"] = True
                else:
                    field = {"baseline": "baseline", "tag": "previous_tag_object", "authorization": "authorization"}[fault]
                    public["baseline_handoff"][field] = "not-the-accepted-value"
                self.rewrite_public(m, public, repo)
                self.reject(lambda: HELPER.check(repo, m))

    def test_substituted_sealed_baseline_and_receipt_identity_reject(self):
        for field, value in (("baseline", "f" * 40), ("phase", "26"), ("eligible", False)):
            with self.subTest(field=field):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                public = self.public(m, repo)
                public[field] = value
                self.rewrite_public(m, public, repo)
                self.reject(lambda: HELPER.check(repo, m))

    def test_protected_edit_or_deletion_rejects_and_preserves_current_bytes(self):
        for fault in ("edit", "delete"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                if fault == "edit":
                    repo.files[PROTECTED] = b"owner current protected bytes\n"
                else:
                    del repo.files[PROTECTED]
                before = dict(repo.files)
                self.reject(lambda: HELPER.check(repo, m), "Snapshot mismatch")
                self.assertEqual(before, repo.files)

    def test_source_evidence_contract_and_authority_hash_drift_rejects(self):
        for rel in (SOURCE, EVIDENCE, CONTRACT, AUTHORIZATION):
            with self.subTest(path=rel):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                repo.files[rel] += b"drift\n"
                before = dict(repo.files)
                self.reject(lambda: HELPER.check(repo, m), "Snapshot mismatch")
                self.assertEqual(before, repo.files)

    def test_unclassified_main_cpp_blocks_before_mock_seal_and_is_preserved(self):
        spec = standard_spec(self.repo)
        self.repo.add_file(MAIN, b"SphereLattice; // owner bytes\n", changed=True)
        before = self.repo.files[MAIN]
        self.reject(lambda: HELPER.seal(self.repo, spec), "Unclassified changes")
        self.assertEqual(before, self.repo.files[MAIN])
        self.assertNotIn("_journals/PHASE_25.json", self.repo.files)

    def test_unclassified_new_paths_after_seal_rejects(self):
        for rel in (MAIN, "bin/Release/new-owner-output.lib", "docs/new-unclassified.md"):
            with self.subTest(path=rel):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                repo.add_file(rel, b"new exact bytes\n", changed=True)
                self.reject(lambda: HELPER.check(repo, m), "Changes appeared after seal")
                self.assertEqual(b"new exact bytes\n", repo.files[rel])

    def test_ownership_overlap_and_duplicate_membership_reject(self):
        for fault in ("owned-protected", "local-protected", "duplicate", "canonical-protected-only"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                spec = standard_spec(repo)
                if fault == "owned-protected":
                    spec["protected_files"].append(SOURCE)
                elif fault == "local-protected":
                    spec["protected_files"].append(AUTHORIZATION)
                elif fault == "duplicate":
                    spec["checkpoint_files"].append(SOURCE)
                else:
                    spec["checkpoint_files"].remove(CANONICAL)
                    spec["protected_files"].append(CANONICAL)
                self.reject(lambda: HELPER.seal(repo, spec))

    def test_sealed_receipt_tampering_is_caught_without_snapshot_refresh(self):
        m = self.seal_mock()
        self.repo.files[m["receipt"]] += b"\n"
        self.reject(lambda: HELPER.check(self.repo, m), "Snapshot mismatch")

    def test_invalid_seal_schema_or_completed_status_rejects_check(self):
        for field, value in (("schema", 1), ("schema", 3), ("status", "COMPLETE"), ("status", "UNKNOWN")):
            with self.subTest(field=field, value=value):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                m[field] = value
                self.reject(lambda: HELPER.check(repo, m), "Invalid or completed seal")


class CanonicalAndIndexTests(OfflineCase):
    def test_canonical_is_retained_when_unchanged_with_raw_and_filtered_blob_refs(self):
        m = self.seal_mock()
        record = m["owner_mutable_after_seal"][CANONICAL]
        self.assertIn(CANONICAL, m["checkpoint_files"])
        for field in ("validated_blob", "blob"):
            self.assertEqual(record[field], self.repo.refs[record[field + "_ref"]])
            self.assertEqual(self.repo.files[CANONICAL], self.repo.objects[record[field]])
        self.assertEqual(m["hashes"][CANONICAL], HELPER.verify_mutable(self.repo, m)[CANONICAL])

    def test_preseal_canonical_qualified_byte_mismatch_is_rejected_and_preserved(self):
        spec = standard_spec(self.repo)
        self.repo.files[CANONICAL] = b"owner-edited bytes must remain\n"
        self.reject(lambda: HELPER.seal(self.repo, spec), "Validated owner-mutable fingerprint mismatch")
        self.assertEqual(b"owner-edited bytes must remain\n", self.repo.files[CANONICAL])

    def test_postseal_canonical_worktree_bytes_are_preserved_and_never_resealed(self):
        m = self.seal_mock()
        approved = self.repo.files[CANONICAL]
        later = b"unexpected owner bytes after seal preserved by existing guard\n"
        self.repo.files[CANONICAL] = later
        self.repo.changed_paths.add(CANONICAL)
        HELPER.check(self.repo, m)
        result = HELPER.finish(self.repo, m)
        self.assertEqual("COMPLETE", result["status"])
        self.assertEqual(later, self.repo.files[CANONICAL])
        self.assertEqual(approved, self.repo.objects[self.repo.index[CANONICAL][1]])
        self.assertEqual(1, sum(call[0] == "commit" for call in self.repo.calls))
        self.assertFalse(any(call[0] == "add" and CANONICAL in call for call in self.repo.calls))

    def test_missing_changed_or_corrupted_retention_refs_and_objects_reject(self):
        for field in ("validated_blob", "blob"):
            for fault in ("ref-missing", "ref-target", "object-type", "object-bytes", "ref-name", "fingerprint"):
                with self.subTest(field=field, fault=fault):
                    repo = MemoryRepo()
                    m = self.seal_mock(repo)
                    record = m["owner_mutable_after_seal"][CANONICAL]
                    oid, ref = record[field], record[field + "_ref"]
                    if fault == "ref-missing":
                        del repo.refs[ref]
                    elif fault == "ref-target":
                        repo.refs[ref] = "f" * 40
                    elif fault == "object-type":
                        repo.types[oid] = "commit"
                    elif fault == "object-bytes":
                        repo.objects[oid] = b"corrupted retained object\n"
                    elif fault == "ref-name":
                        record[field + "_ref"] += "wrong"
                    else:
                        record["fingerprint"] = {"sha256": "0" * 64, "executable": None if os.name == "nt" else False}
                    self.reject(lambda: HELPER.verify_mutable(repo, m))

    def test_canonical_missing_reparse_or_changed_mode_is_rejected(self):
        for fault in ("missing", "reparse", "nonregular", "git-mode"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                if fault == "missing":
                    del repo.files[CANONICAL]
                elif fault == "reparse":
                    repo.reparse.add(CANONICAL)
                elif fault == "nonregular":
                    repo.nonregular.add(CANONICAL)
                else:
                    m["owner_mutable_after_seal"][CANONICAL]["mode"] = "120000"
                self.reject(lambda: HELPER.verify_mutable(repo, m))

    def test_prestaged_and_unmerged_entries_block_before_seal(self):
        for stage in ("0", "1", "2", "3"):
            with self.subTest(stage=stage):
                repo = MemoryRepo()
                spec = standard_spec(repo)
                repo.index["unrelated.txt"] = ("100644", "f" * 40, stage, "H")
                self.reject(lambda: HELPER.seal(repo, spec), "Pre-existing staged or unmerged")
                self.assertIn("unrelated.txt", repo.index)
                self.assertNotIn("_journals/PHASE_25.json", repo.files)

    def test_index_identity_includes_blobs_modes_stages_and_flags(self):
        for fault, position, value in (("blob", 1, "f" * 40), ("mode", 0, "100755"),
                                       ("unmerged", 2, "2"), ("skip-worktree", 3, "S"),
                                       ("assume-unchanged", 3, "h")):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                entry = list(repo.index[SOURCE])
                entry[position] = value
                repo.index[SOURCE] = tuple(entry)
                self.reject(lambda: HELPER.verify_mutable(repo, m), "Unexpected staged/index changes")

    def test_exact_staging_rejects_blob_mode_stage_and_unexpected_entries(self):
        for fault in ("blob", "mode", "stage", "missing"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                record = m["owner_mutable_after_seal"][CANONICAL]
                entry = [record["mode"], record["blob"], "0", "H"]
                if fault == "missing":
                    del repo.index[CANONICAL]
                else:
                    entry[{"blob": 1, "mode": 0, "stage": 2}[fault]] = {"blob": "f" * 40, "mode": "100755", "stage": "2"}[fault]
                    repo.index[CANONICAL] = tuple(entry)
                self.reject(lambda: HELPER.staged_matches_worktree(repo, [CANONICAL], m["owner_mutable_after_seal"]))

    def test_ordinary_index_blob_and_mode_must_match_worktree(self):
        standard_spec(self.repo)
        for mode, oid, stage in (("100644", "f" * 40, "0"), ("120000", "f" * 40, "0"),
                                 ("100644", "f" * 40, "2")):
            with self.subTest(mode=mode, stage=stage):
                self.repo.index[SOURCE] = (mode, oid, stage, "H")
                self.reject(lambda: HELPER.staged_matches_worktree(self.repo, [SOURCE]))


class RecoveryTests(OfflineCase):
    def test_pending_precommit_and_postcommit_check_use_original_state(self):
        for postcommit in (False, True):
            with self.subTest(postcommit=postcommit):
                self.repo = MemoryRepo()
                m = self.pending_mock(postcommit=postcommit)
                with patch.object(HELPER, "baseline_gate", side_effect=AssertionError("Pending must not demand baseline HEAD")):
                    public = HELPER.check(self.repo, m, pending=True)
                self.assertEqual(BASELINE, public["baseline"])
                if postcommit:
                    self.assertNotEqual(BASELINE, self.repo.head)
                    self.assertEqual("25", self.repo.state()[1]["Current approved phase"])
                    self.assertEqual("24", m["state"]["Current approved phase"])

    def test_pending_rechecks_original_bridge_authority_after_commit(self):
        m = self.pending_mock(postcommit=True)
        self.repo.files[AUTHORIZATION] += b"altered\n"
        # Isolate bridge revalidation from ordinary snapshot verification.
        m["hashes"][AUTHORIZATION] = self.repo.fingerprint(AUTHORIZATION)
        self.reject(lambda: HELPER.check(self.repo, m, pending=True))

    def test_pending_cannot_substitute_baseline_original_state_or_handoff(self):
        for fault in ("baseline", "original-state", "handoff"):
            with self.subTest(fault=fault):
                self.repo = MemoryRepo()
                m = self.pending_mock(postcommit=True)
                if fault == "baseline":
                    m["baseline"] = "e" * 40
                elif fault == "original-state":
                    m["state"]["Current approved phase"] = "25"
                else:
                    public = self.public(m)
                    public["baseline_handoff"]["baseline"] = "e" * 40
                    self.rewrite_public(m, public)
                self.reject(lambda: HELPER.check(self.repo, m, pending=True))

    def test_pending_state_must_be_original_or_exact_recorded_state_after(self):
        m = self.pending_mock(postcommit=True)
        self.repo.files[HELPER.STATE] += b"owner unrelated state drift\n"
        current = self.repo.files[HELPER.STATE]
        self.reject(lambda: HELPER.check(self.repo, m, pending=True), "Workflow state changed")
        self.assertEqual(current, self.repo.files[HELPER.STATE])

    def test_interrupted_staging_commit_tag_and_each_push_resume_exact_checkpoint(self):
        tag = "refs/tags/pre-editor-phase-25-approved"
        for stage in ("add", "commit", "tag", "push", ("push", "origin", tag + ":" + tag)):
            with self.subTest(stage=stage):
                self.repo = MemoryRepo()
                m = self.seal_mock()
                original_hashes = copy.deepcopy(m["hashes"])
                original_canonical = self.repo.files[CANONICAL]
                original_protected = self.repo.files[PROTECTED]
                self.repo.fail_once = stage
                self.reject(lambda: HELPER.finish(self.repo, m), "Injected interrupted mock")
                saved = self.repo.load("25")
                self.assertEqual("PENDING", saved["status"])
                self.assertEqual(original_hashes, saved["hashes"])
                with patch.object(HELPER, "seal", side_effect=AssertionError("Recovery may not reseal")):
                    result = HELPER.finish(self.repo, saved)
                self.assertEqual("COMPLETE", result["status"])
                self.assertEqual(BASELINE, self.repo.parents[self.repo.head])
                self.assertEqual(saved["transaction"]["tree"], self.repo.trees[self.repo.head])
                self.assertEqual(original_canonical, self.repo.files[CANONICAL])
                self.assertEqual(original_protected, self.repo.files[PROTECTED])
                self.assertFalse(any(call[0] == "add" and PROTECTED in call for call in self.repo.calls))
                for call in self.repo.calls:
                    self.assertNotIn("--force", call)
                    self.assertNotIn("--no-verify", call)
                    self.assertNotIn("-f", call)
                    self.assertFalse(any("hooksPath" in part for part in call))

    def test_partial_staging_with_changed_index_stops_and_preserves_index(self):
        # Existing fail-closed behavior: interruption after ordinary add but before
        # the transaction index identity is saved is not silently rebaselined.
        m = self.seal_mock()
        self.repo.fail_once = "update-index"
        self.reject(lambda: HELPER.finish(self.repo, m), "Injected interrupted mock")
        index = dict(self.repo.index)
        saved = self.repo.load("25")
        self.reject(lambda: HELPER.finish(self.repo, saved), "Unexpected staged/index changes")
        self.assertEqual(index, self.repo.index)
        self.assertEqual(BASELINE, self.repo.head)

    def test_recovery_rejects_wrong_commit_tree_parent_merge_or_recorded_commit(self):
        for fault in ("tree", "parent", "merge", "recorded-commit", "head-reverted"):
            with self.subTest(fault=fault):
                self.repo = MemoryRepo()
                m = self.pending_mock(postcommit=True)
                if fault == "tree":
                    self.repo.trees[self.repo.head] = "c" * 40
                elif fault == "parent":
                    self.repo.parents[self.repo.head] = PREVIOUS_COMMIT
                elif fault == "merge":
                    self.repo.parents[self.repo.head] = BASELINE + " " + PREVIOUS_COMMIT
                elif fault == "recorded-commit":
                    m["transaction"]["commit"] = "c" * 40
                else:
                    self.repo.head = BASELINE
                self.reject(lambda: HELPER.finish(self.repo, m))
                self.assertFalse(any(call[0] in ("tag", "push") for call in self.repo.calls))

    def test_recovery_rejects_existing_wrong_or_lightweight_phase25_tag_without_replacing(self):
        for fault in ("wrong-commit", "lightweight"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                repo.fail_once = "tag"
                self.reject(lambda: HELPER.finish(repo, m))
                saved = repo.load("25")
                ref = "refs/tags/pre-editor-phase-25-approved"
                repo.refs[ref] = "d" * 40
                repo.types["d" * 40] = "tag" if fault == "wrong-commit" else "commit"
                repo.peels[ref] = "e" * 40 if fault == "wrong-commit" else repo.head
                before_refs = dict(repo.refs)
                self.reject(lambda: HELPER.finish(repo, saved))
                self.assertEqual(before_refs, repo.refs)
                self.assertFalse(any(call[0] == "push" for call in repo.calls))

    def test_wrong_destination_disabled_policy_or_wrong_explicit_target_stops_before_writes(self):
        for fault in ("destination", "policy-disabled", "authorization-target"):
            with self.subTest(fault=fault):
                repo = MemoryRepo()
                m = self.seal_mock(repo)
                authorization = None
                if fault == "destination":
                    repo.destination = "https://github.com/other/repository.git"
                elif fault == "policy-disabled":
                    policy = json.loads(repo.files[HELPER.PUBLICATION_POLICY])
                    policy["enabled"] = False
                    repo.files[HELPER.PUBLICATION_POLICY] = HELPER.encode_json(policy)
                else:
                    authorization = {"repository": "other/repository", "branch": "pre-editor/refactor", "tag": "pre-editor-phase-25-approved"}
                writes = list(repo.memory_writes)
                self.reject(lambda: HELPER.finish(repo, m, authorization))
                self.assertEqual(writes, repo.memory_writes)
                self.assertIsNone(m["transaction"])
                self.assertFalse(any(call[0] in ("add", "commit", "tag", "push") for call in repo.calls))

    def test_remote_verification_mismatch_blocks_complete_and_preserves_transaction(self):
        m = self.seal_mock()
        original = self.repo.git

        def mismatching_remote(*args, **kwargs):
            if args[0] == "ls-remote":
                return b""
            return original(*args, **kwargs)

        with patch.object(self.repo, "git", mismatching_remote):
            self.reject(lambda: HELPER.finish(self.repo, m), "Remote checkpoint is incomplete")
        saved = self.repo.load("25")
        self.assertEqual("PENDING", saved["status"])
        self.assertTrue(saved["transaction"]["branch_pushed"])
        self.assertTrue(saved["transaction"]["tag_pushed"])
        result = HELPER.finish(self.repo, saved)
        self.assertEqual("COMPLETE", result["status"])

    def test_completed_same_checkpoint_is_finish_only_without_reseal_or_bridge_revalidation(self):
        m = self.seal_mock()
        HELPER.finish(self.repo, m)
        calls = len(self.repo.calls)
        writes = len(self.repo.memory_writes)
        with patch.object(HELPER, "check", side_effect=AssertionError("Completed path must not revalidate")), \
             patch.object(HELPER, "seal", side_effect=AssertionError("Completed path must not reseal")), \
             patch.object(HELPER, "phase25_accepted_collider_gate", side_effect=AssertionError("Completed path must not reopen bridge")):
            result = HELPER.finish(self.repo, m)
        self.assertEqual("ALREADY_COMPLETE", result["status"])
        self.assertEqual(writes, len(self.repo.memory_writes))
        self.assertFalse(any(call[0] in ("add", "commit", "tag", "push") for call in self.repo.calls[calls:]))


class ResultsAndPathsTests(OfflineCase):
    def test_named_accepted_exception_retains_actual_failure(self):
        spec = standard_spec(self.repo)
        row = {"check": "named accepted claim limit", "result": "ACCEPTED_EXCEPTION", "command": "historical check",
               "evidence": "historical failed evidence", "actual_outcome": "FAIL retained exactly",
               "owner_acceptance": "Exact named owner acceptance"}
        spec["validation"].append(row)
        before = copy.deepcopy(spec)
        HELPER.validate_results(spec)
        self.assertEqual(before, spec)
        self.assertEqual("FAIL retained exactly", spec["validation"][-1]["actual_outcome"])

    def test_exception_without_actual_outcome_or_specific_acceptance_is_rejected(self):
        for omitted in ("actual_outcome", "owner_acceptance"):
            with self.subTest(omitted=omitted):
                spec = standard_spec(self.repo)
                row = {"check": "named limit", "result": "ACCEPTED_EXCEPTION", "command": "mock", "evidence": EVIDENCE,
                       "actual_outcome": "FAIL", "owner_acceptance": "named acceptance"}
                del row[omitted]
                spec["validation"] = [row]
                self.reject(lambda: HELPER.validate_results(spec), "Specific exception acceptance missing")

    def test_fail_incomplete_pending_and_blocked_results_never_become_pass(self):
        for outcome in ("FAIL", "INCOMPLETE", "INCONCLUSIVE", "PENDING", "BLOCKED"):
            with self.subTest(outcome=outcome):
                spec = standard_spec(self.repo)
                spec["validation"][0]["result"] = outcome
                before = copy.deepcopy(spec)
                self.reject(lambda: HELPER.validate_results(spec), "Unresolved validation")
                self.assertEqual(before, spec)

    def test_source_human_pending_and_absent_owner_approval_rows_block_before_any_seal_mutation(self):
        for check in ("main.cpp disposition unresolved", "final human RBS acceptance pending", "explicit Phase25 approval absent"):
            with self.subTest(check=check):
                repo = MemoryRepo()
                spec = standard_spec(repo)
                spec["validation"].append({"check": check, "result": "BLOCKED", "command": "not invoked",
                                           "evidence": "Mock gate, no actual acceptance"})
                self.reject(lambda: HELPER.seal(repo, spec), "Unresolved validation")
                self.assertNotIn("_journals/PHASE_25.json", repo.files)
                self.assertFalse(repo.calls)
                self.assertFalse(repo.memory_writes)

    def test_invalid_coverage_summary_required_fields_na_reason_and_findings_reject(self):
        for fault in ("summary", "coverage", "check", "result", "command", "evidence", "na-reason", "finding"):
            with self.subTest(fault=fault):
                spec = standard_spec(self.repo)
                if fault == "summary":
                    spec["summary"] = " "
                elif fault == "coverage":
                    spec["validation"] = []
                elif fault == "na-reason":
                    spec["validation"][0]["result"] = "NOT_APPLICABLE"
                elif fault == "finding":
                    spec["findings"] = [{"finding": "unresolved issue", "status": "OPEN", "disposition": "pending"}]
                else:
                    spec["validation"][0][fault] = ""
                self.reject(lambda: HELPER.validate_results(spec))

    def test_unsafe_relative_paths_are_rejected_before_access(self):
        with tempfile.TemporaryDirectory(prefix="path-fixture-", dir=TEST_DIR) as folder:
            root = Path(folder).resolve()
            self.assertEqual(TEST_DIR, root.parent)
            repo = HELPER.Repo.__new__(HELPER.Repo)
            repo.root = root
            for rel in ("../outside.txt", "/absolute.txt", "C:/outside.txt", "a\\b.txt", ".git/config",
                        "a/../b", "a//b", "folder/", "", "a\x00b"):
                with self.subTest(path=rel):
                    self.reject(lambda: repo.path(rel))

    def test_escaping_reparse_resolution_rejects_before_reading_target(self):
        with tempfile.TemporaryDirectory(prefix="path-fixture-", dir=TEST_DIR) as folder:
            root = Path(folder).resolve()
            self.assertEqual(TEST_DIR, root.parent)
            repo = HELPER.Repo.__new__(HELPER.Repo)
            repo.root = root
            target = root / "assets/file.txt"
            real_resolve = Path.resolve

            def resolution(path, *args, **kwargs):
                return root.parent / "outside-path/file.txt" if path == target else real_resolve(path, *args, **kwargs)

            with patch.object(Path, "resolve", resolution), \
                 patch.object(Path, "read_bytes", side_effect=AssertionError("Escaping target must not be read")):
                self.reject(lambda: repo.path("assets/file.txt"), "path leaves repository")

    def test_contained_symlink_is_not_silently_admitted(self):
        with tempfile.TemporaryDirectory(prefix="path-fixture-", dir=TEST_DIR) as folder:
            root = Path(folder).resolve()
            self.assertEqual(TEST_DIR, root.parent)
            repo = HELPER.Repo.__new__(HELPER.Repo)
            repo.root = root
            with patch.object(Path, "is_symlink", lambda p: p == root / "assets"), \
                 patch.object(Path, "read_bytes", side_effect=AssertionError("Symlink target must not be read")):
                self.reject(lambda: repo.path("assets/file.txt"), "symlink needs explicit reviewed support")

    def test_directory_cannot_replace_required_regular_file(self):
        with tempfile.TemporaryDirectory(prefix="path-fixture-", dir=TEST_DIR) as folder:
            root = Path(folder).resolve()
            self.assertEqual(TEST_DIR, root.parent)
            (root / "directory").mkdir()
            repo = HELPER.Repo.__new__(HELPER.Repo)
            repo.root = root
            self.reject(lambda: repo.path("directory"), "expected file, not directory")


class UnchangedWorkflowTests(OfflineCase):
    def test_all_legacy_functions_and_classes_except_three_authorized_edits_are_ast_identical(self):
        self.assertIsNotNone(BEFORE, "Original helper is required")
        old_tree = ast.parse(OPTIONS.before.read_text(encoding="utf-8"))
        new_tree = ast.parse(OPTIONS.helper.read_text(encoding="utf-8"))
        old_items = {node.name: node for node in old_tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
        new_items = {node.name: node for node in new_tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
        for name in sorted(set(old_items) - {"baseline_gate", "seal", "check"}):
            with self.subTest(name=name):
                self.assertEqual(ast.dump(old_items[name], include_attributes=False),
                                 ast.dump(new_items[name], include_attributes=False))
        self.assertEqual({"phase25_handoff_inputs", "phase25_accepted_collider_gate"}, set(new_items) - set(old_items))

    def test_original_global_policy_constants_and_imports_are_unchanged(self):
        old_tree = ast.parse(OPTIONS.before.read_text(encoding="utf-8"))
        new_tree = ast.parse(OPTIONS.helper.read_text(encoding="utf-8"))

        def globals_of(tree):
            return {node.targets[0].id: ast.dump(node.value, include_attributes=False)
                    for node in tree.body if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}

        old_globals, new_globals = globals_of(old_tree), globals_of(new_tree)
        for name, value in old_globals.items():
            with self.subTest(name=name):
                self.assertEqual(value, new_globals[name])
        self.assertEqual([ast.dump(node) for node in old_tree.body if isinstance(node, (ast.Import, ast.ImportFrom))],
                         [ast.dump(node) for node in new_tree.body if isinstance(node, (ast.Import, ast.ImportFrom))])

    def test_phase26_uses_only_normal_immediate_approved_predecessor(self):
        for module in (BEFORE, HELPER):
            with self.subTest(module=module.__name__):
                module.configure_workflow("pre-editor")
                repo = MemoryRepo(module)
                phase25 = "f" * 40
                tag = "refs/tags/pre-editor-phase-25-approved"
                repo.head = phase25
                repo.refs[tag] = "e" * 40
                repo.peels[tag] = phase25
                repo.types["e" * 40] = "tag"
                repo.set_state(dict(repo.state_fields, **{"Current approved phase": "25", "Current approved tag": tag[10:], "Next expected phase": "26"}))
                repo.files["_journals/PHASE_25.json"] = module.encode_json({"status": "COMPLETE", "transaction": {
                    "commit": phase25, "branch_pushed": True, "tag_pushed": True}})
                with patch.object(HELPER, "phase25_accepted_collider_gate", side_effect=AssertionError("Phase26 bridge leakage")):
                    module.baseline_gate(repo, "26", phase25, repo.state_fields)
                repo.peels[tag] = BASELINE
                with self.assertRaises(module.Blocked):
                    module.baseline_gate(repo, "26", phase25, repo.state_fields)

    def test_phase22_frozen_predecessor_exception_keeps_original_behavior(self):
        frozen = "3ce1f6cbd9245893876c34441055e3a63ed1f7b6"
        approved = "6263b3719bfd1b20d3ed8c40abf803580857a82c"
        for module in (BEFORE, HELPER):
            with self.subTest(module=module.__name__):
                module.configure_workflow("pre-editor")
                repo = MemoryRepo(module)
                repo.head = frozen
                repo.parents[frozen] = approved
                repo.types[frozen] = "commit"
                tag = "refs/tags/pre-editor-phase-21-frozen-unapproved"
                repo.refs[tag] = "86ab5b8373c1cbc37357d084509f828a939d7a2a"
                repo.types[repo.refs[tag]] = "tag"
                repo.peels[tag] = frozen
                repo.refs["refs/tags/pre-editor-phase-20-approved"] = "e" * 40
                repo.peels["refs/tags/pre-editor-phase-20-approved"] = approved
                repo.set_state(dict(repo.state_fields, **{"Current approved phase": "20", "Current approved tag": "pre-editor-phase-20-approved", "Next expected phase": "21"}))
                repo.files["_journals/PHASE_20.json"] = module.encode_json({"status": "COMPLETE", "transaction": {
                    "commit": approved, "branch_pushed": True, "tag_pushed": True}})
                with patch.object(HELPER, "phase25_accepted_collider_gate", side_effect=AssertionError("Phase22 bridge leakage")):
                    module.baseline_gate(repo, "22", frozen, repo.state_fields)
                repo.refs["refs/tags/pre-editor-phase-21-approved"] = "a" * 40
                with self.assertRaises(module.Blocked):
                    module.baseline_gate(repo, "22", frozen, repo.state_fields)

    def test_rendering_phase25_uses_unchanged_rendering_predecessor_gate(self):
        for module in (BEFORE, HELPER):
            with self.subTest(module=module.__name__):
                module.configure_workflow("rendering")
                repo = MemoryRepo(module)
                repo.branch = "rendering/refactor"
                tag = "refs/tags/render-refactor-phase-24-approved"
                repo.refs[tag] = "e" * 40
                repo.peels[tag] = BASELINE
                repo.set_state(dict(repo.state_fields, **{"Refactor branch": repo.branch,
                    "Current approved tag": tag[10:]}))
                with patch.object(HELPER, "phase25_accepted_collider_gate", side_effect=AssertionError("Rendering bridge leakage")):
                    module.baseline_gate(repo, "25", BASELINE, repo.state_fields)
                repo.peels[tag] = "f" * 40
                with self.assertRaises(module.Blocked):
                    module.baseline_gate(repo, "25", BASELINE, repo.state_fields)

    def test_rendering_phase02_exact_handoff_is_unchanged(self):
        for module in (BEFORE, HELPER):
            with self.subTest(module=module.__name__):
                module.configure_workflow("rendering")
                repo = MemoryRepo(module)
                h = module.PHASE02_HANDOFF
                repo.head = h["baseline"]
                repo.parents[h["baseline"]] = h["previous_commit"]
                tag = "refs/tags/" + h["previous_tag"]
                repo.refs[tag] = h["previous_tag_object"]
                repo.peels[tag] = h["previous_commit"]
                repo.types[h["previous_tag_object"]] = "tag"
                repo.branch = "rendering/refactor"
                repo.set_state(dict(repo.state_fields, **{"Refactor branch": repo.branch,
                    "Current approved phase": "01", "Current approved tag": h["previous_tag"], "Next expected phase": "02"}))
                receipt = "rendering-checkpoints/phase-01.json"
                repo.add_file(receipt, b"mock historical receipt\n", tracked=True)
                repo.files["_journals/PHASE_01.json"] = module.encode_json({"status": "COMPLETE", "transaction": {
                    "commit": h["previous_commit"], "branch_pushed": True, "tag_pushed": True},
                    "push_destination": DESTINATION, "receipt": receipt, "hashes": {receipt: repo.fingerprint(receipt)}})
                with patch.object(HELPER, "phase25_accepted_collider_gate", side_effect=AssertionError("Rendering02 bridge leakage")):
                    module.baseline_gate(repo, "02", h["baseline"], repo.state_fields)
                repo.parents[h["baseline"]] += " " + "f" * 40
                with self.assertRaises(module.Blocked):
                    module.baseline_gate(repo, "02", h["baseline"], repo.state_fields)

    def test_existing_completed_phase24_remains_finish_only(self):
        for module in (BEFORE, HELPER):
            with self.subTest(module=module.__name__):
                module.configure_workflow("pre-editor")
                repo = MemoryRepo(module)
                standard_spec(repo)
                m = repo.load("24")
                with patch.object(module, "check", side_effect=AssertionError("No historical revalidation")), \
                     patch.object(module, "seal", side_effect=AssertionError("No historical reseal")):
                    result = module.finish(repo, m)
                self.assertEqual("ALREADY_COMPLETE", result["status"])
                self.assertEqual(PREVIOUS_COMMIT, result["commit"])
                self.assertFalse(any(call[0] in ("add", "commit", "tag", "push") for call in repo.calls))


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0], *UNITTEST_ARGS], verbosity=2)
