"""Verify and restore the recovery package into an isolated test directory only."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import types
import zipfile

ROOT = Path(__file__).resolve().parents[5]
BASE = ROOT / 'logs/pre_editor/phase-25/publication-guard-implementation-01'
RECOVERY = ROOT / 'docs/pre_editor/revisions/PHASE_25_PUBLICATION_GUARD_01'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    record = json.loads((RECOVERY / 'RECOVERY.json').read_bytes())
    archive = ROOT / record['archive']
    assert sha(archive.read_bytes()) == record['archive_sha256']
    target = BASE / 'tests/recovery-restoration-01'
    target.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        assert len(names) == len(set(names)) and set(names) == set(record['members'])
        for name in names:
            rel = PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
            info = zipped.getinfo(name)
            assert not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16)
            raw = zipped.read(name)
            expected = record['members'][name]
            assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
            path = target / name
            assert path.resolve().is_relative_to(target.resolve())
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as out:
                out.write(raw)
            assert sha(path.read_bytes()) == expected['sha256']
    helper_path = target / '.codex/tools/rendering_checkpoint.py'
    helper_bytes = helper_path.read_bytes()
    assert sha(helper_bytes) == record['helper_after_sha256']
    helper = types.ModuleType('isolated_recovered_helper')
    helper.__file__ = str(helper_path)
    exec(compile(helper_bytes, str(helper_path), 'exec'), helper.__dict__)
    helper.configure_workflow('pre-editor')
    for name, expected in helper.phase25_handoff_inputs().items():
        assert sha((target / name).read_bytes()) == expected, name
    journal = target / 'logs/pre_editor/phase-25/publication-guard-implementation-01/before/PHASE_24.journal.json'
    assert sha(journal.read_bytes()) == helper.PHASE25_HANDOFF['previous_journal_sha256']
    assert (target / helper.PHASE25_HANDOFF['authorization']).read_bytes() == (target / helper.PHASE25_HANDOFF['recovery_copy']).read_bytes()
    result = {
        'status': 'PASS', 'members_verified_and_restored': len(names),
        'uncompressed_bytes': sum(v['bytes'] for v in record['members'].values()),
        'archive_sha256': record['archive_sha256'],
        'helper_after_sha256': record['helper_after_sha256'],
        'all_required_handoff_inputs_recoverable_and_hash_verified': True,
        'private_predecessor_journal_copy_recoverable': True,
        'live_governance_or_source_restored': False,
        'real_helper_transactions': 0,
        'scope': 'Isolated temporary restoration proves package completeness; no automatic live fallback is implemented.',
    }
    with (BASE / 'tests/recovery-package-verification-01.json').open('x', encoding='utf-8') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
